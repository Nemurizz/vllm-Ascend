#!/bin/bash
set -euo pipefail
source /root/vllm_project/scripts/activate_stack026.sh
while [ -e /proc/133742/stat ] && [ "$(awk '{print $3}' /proc/133742/stat)" != Z ]; do sleep 5; done
python -c 'import json; assert json.load(open("/root/vllm_project/results/raw/issue16637-static-graph.json"))["status"]=="completed"'
for variant in dynamic_graph eager_dynamic; do
  python -u /root/vllm_project/scripts/benchmark_issue16637.py --model /data/vllm_project/models/Qwen3.5-4B --variant "$variant" --requests 32 --repeats 3 --output "/root/vllm_project/results/raw/issue16637-$variant.json" > "/root/vllm_project/logs/stack026/$variant.log" 2>&1
  echo "$variant COMPLETED"
done
cd /root/vllm_project/src/stack026/vllm
git switch -c codex/issue16637-026-experiment
git apply --check /root/vllm_project/scripts/issue16637-v0.26-candidate.patch
git apply /root/vllm_project/scripts/issue16637-v0.26-candidate.patch
python -u /root/vllm_project/scripts/benchmark_issue16637.py --model /data/vllm_project/models/Qwen3.5-4B --variant dynamic_patched --requests 32 --repeats 3 --output /root/vllm_project/results/raw/issue16637-dynamic_patched.json > /root/vllm_project/logs/stack026/dynamic_patched.log 2>&1
echo ALL_FOUR_COMPLETED
