#!/usr/bin/env bash
set -u
source /data/vllm-ascend-env/bin/activate
source /root/vllm_project/src/env.sh
LOG=/root/vllm_project/logs/qwen3_8b_graph_metrics_valid.log
PIDFILE=/root/vllm_project/graph_metrics_valid.pid
setsid bash /root/vllm_project/scripts/serve_qwen3_8b_metrics.sh 8010 >"$LOG" 2>&1 < /dev/null &
pid=$!
echo "$pid" > "$PIDFILE"
ready=0
for _ in $(seq 1 180); do
  if python -c "import urllib.request; urllib.request.urlopen('http://127.0.0.1:8010/health', timeout=1)" >/dev/null 2>&1; then
    ready=1
    echo "ready=1"
    break
  fi
  sleep 2
done
if [ "$ready" -ne 1 ]; then
  echo "ready=0"
  tail -80 "$LOG"
  kill -- -"$pid" 2>/dev/null || true
  exit 2
fi
python /root/vllm_project/scripts/benchmark_concurrent.py \
  --base-url http://127.0.0.1:8010 \
  --cases /root/vllm_project/workloads/graph_pad5.json \
  --repeats 2 --concurrency 5 \
  --output /root/vllm_project/results/raw/qwen3_8b_graph_pad5_metrics_valid.json
sleep 10
grep -E 'CUDAGraph|cudagraph|num_padd|Padded|padded|Replaying|metrics|error|Error' "$LOG" | tail -200
kill -- -"$pid" 2>/dev/null || true
sleep 8
pkill -TERM -f 'vllm.entrypoints.openai.api_server.*8010' 2>/dev/null || true
echo "cleanup_done"
npu-smi info
