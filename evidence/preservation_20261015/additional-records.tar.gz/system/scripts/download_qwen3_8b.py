import json
from huggingface_hub import HfApi, snapshot_download
api=HfApi(endpoint='https://hf-mirror.com')
info=api.model_info('Qwen/Qwen3-8B')
print('model_revision',info.sha,flush=True)
open('/root/vllm_project/evidence/qwen3_8b_revision.json','w').write(json.dumps({'repo':'Qwen/Qwen3-8B','revision':info.sha},indent=2))
p=snapshot_download('Qwen/Qwen3-8B',revision=info.sha,local_dir='/data/vllm_project/models/Qwen3-8B',max_workers=4)
print('complete',p,flush=True)
