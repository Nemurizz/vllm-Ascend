#!/usr/bin/env bash
set -euo pipefail
source /data/vllm-ascend-env/bin/activate
source /root/vllm_project/src/env.sh
PORT=${1:-8011}
MODEL=/data/vllm_project/models/Qwen3-8B
exec python -m vllm.entrypoints.openai.api_server \
  --model "$MODEL" --served-model-name Qwen3-8B \
  --dtype bfloat16 --max-model-len 4096 --max-num-seqs 8 \
  --max-num-batched-tokens 1024 --gpu-memory-utilization 0.80 \
  --host 127.0.0.1 --port "$PORT" --no-enable-log-requests \
  --cudagraph-metrics \
  --compilation-config '{"cudagraph_capture_sizes":[1,2,4,5,8]}'
