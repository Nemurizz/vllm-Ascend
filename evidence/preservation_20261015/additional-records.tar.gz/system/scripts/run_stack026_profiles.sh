#!/bin/bash
set -euo pipefail
source /root/vllm_project/scripts/activate_stack026.sh
while [ -e /proc/135205/stat ] && [ "$(awk '{print $3}' /proc/135205/stat)" != Z ]; do sleep 5; done
python - <<'PY'
import json
for n in ['static-graph','dynamic_graph','eager_dynamic','dynamic_patched']:
 j=json.load(open('/root/vllm_project/results/raw/issue16637-'+n+'.json'));assert j['status']=='completed',(n,j['status'])
PY
cd /root/vllm_project/src/stack026/vllm
git add vllm/v1/core/sched/scheduler.py
git -c user.name=Codex -c user.email=codex@localhost commit -m 'experiment: validate padding candidate on pinned v0.26'
mkdir -p /root/vllm_project/evidence/stack026
git bundle create /root/vllm_project/evidence/stack026/vllm-16637-026.bundle codex/issue16637-026-experiment ^568afb3a13806beb53bb2e6bd518269357b237c0
git switch --detach 568afb3a13806beb53bb2e6bd518269357b237c0
for variant in static_graph dynamic_graph; do
 python -u /root/vllm_project/scripts/benchmark_issue16637.py --model /data/vllm_project/models/Qwen3.5-4B --variant "$variant" --requests 8 --concurrency 8 --output-tokens 64 --repeats 1 --profile-dir "/root/vllm_project/profiles/stack026/16637-$variant" --output "/root/vllm_project/results/raw/issue16637-$variant-profile.json" > "/root/vllm_project/logs/stack026/$variant-profile.log" 2>&1
 echo "$variant PROFILE_COMPLETED"
done
for length in 32768 98304; do
 for seqs in 1 256; do
  name=15920-L${length}-seqs${seqs}
  export ISSUE15920_INIT_PROFILE_DIR=/root/vllm_project/profiles/stack026/$name/init
  timeout --signal=TERM --kill-after=30s 900 python -u /root/vllm_project/scripts/probe_issue15920_long_context.py --model /data/vllm_project/models/Qwen3.5-4B --input-tokens "$length" --max-num-seqs "$seqs" --profile-dir "/root/vllm_project/profiles/stack026/$name/runtime" --output "/root/vllm_project/results/raw/$name.json" > "/root/vllm_project/logs/stack026/$name.log" 2>&1
  echo "$name COMPLETED"
 done
done
echo ALL_PROFILES_COMPLETED
