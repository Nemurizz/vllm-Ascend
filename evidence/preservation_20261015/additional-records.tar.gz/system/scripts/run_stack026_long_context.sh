#!/bin/bash
set -euo pipefail
source /root/vllm_project/scripts/activate_stack026.sh
while [ -e /proc/147188/stat ] && [ "$(awk '{print $3}' /proc/147188/stat)" != Z ]; do sleep 5; done
python - <<'PY'
import json
j=json.load(open('/root/vllm_project/results/raw/issue16637-paired-abba.json'));assert j['status']=='completed',j.get('error');print(j['comparisons'])
PY
for length in 32768 98304; do
 for seqs in 1 256; do
  name=15920-L${length}-seqs${seqs}
  export ISSUE15920_INIT_PROFILE_DIR=/root/vllm_project/profiles/stack026/$name/init
  timeout --signal=TERM --kill-after=30s 900 python -u /root/vllm_project/scripts/probe_issue15920_long_context.py --model /data/vllm_project/models/Qwen3.5-4B --input-tokens "$length" --max-num-seqs "$seqs" --profile-dir "/root/vllm_project/profiles/stack026/$name/runtime" --output "/root/vllm_project/results/raw/$name.json" > "/root/vllm_project/logs/stack026/$name.log" 2>&1
  echo "$name COMPLETED"
 done
done
echo ALL_LONG_PROFILES_COMPLETED
