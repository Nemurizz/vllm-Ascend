#!/bin/bash
set -u
source /root/vllm_project/scripts/activate_stack026.sh
while IFS= read -r path; do
 msprof --export=on --output="$path" > "$path/msprof-export.log" 2>&1
 status=$?
 echo "rc=$status $path"
done < <(find /root/vllm_project/profiles/stack026 -type d -name 'PROF_*')
echo MSPROF_EXPORT_FINISHED
