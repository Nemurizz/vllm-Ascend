#!/usr/bin/env bash
set -euo pipefail
source /data/vllm-ascend-env/bin/activate
source /root/vllm_project/src/env.sh
unset VLLM_LOGGING_CONFIG_PATH || true
MODE=${1:-graph}
PORT=${2:-8000}
MODEL=/data/vllm_project/models/Qwen3-8B
ARGS=(
  --model "$MODEL"
  --served-model-name Qwen3-8B
  --dtype bfloat16
  --max-model-len 4096
  --max-num-seqs 8
  --max-num-batched-tokens 1024
  --gpu-memory-utilization 0.80
  --host 127.0.0.1
  --port "$PORT"
  --no-enable-log-requests
)
if [[ "$MODE" == eager ]]; then
  ARGS+=(--enforce-eager)
elif [[ "$MODE" == no_chunk ]]; then ARGS+=(--no-enable-chunked-prefill --max-model-len 4096 --max-num-batched-tokens 4096)
fi
exec python -m vllm.entrypoints.openai.api_server "${ARGS[@]}"
