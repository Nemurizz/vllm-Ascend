import torch
x=torch.randn((1024,1024),device='npu')
y=torch.mm(x,x)
torch.npu.synchronize()
print('npu_smoke_sum',float(y[0,0].cpu()))
