import torch, torch_npu, json

torch.npu.set_device(0)
torch.npu.empty_cache(); torch.npu.synchronize()
def snap(tag):
    free,total=torch.npu.mem_get_info()
    st=torch.npu.memory_stats()
    return {'tag':tag,'free':int(free),'total':int(total),'used_device':int(total-free),'allocated':int(st.get('allocated_bytes.all.current',0)),'reserved':int(st.get('reserved_bytes.all.current',0))}
rows=[snap('before')]
x=torch.rand((2,4),dtype=torch.float16,device='npu')
weight=torch.rand((2,4),dtype=torch.float16,device='npu')
c=torch.rand((4,4),dtype=torch.float32,device='npu')
torch.npu.synchronize(); rows.append(snap('inputs'))
torch_npu._npu_matmul_add_fp32(x,weight,c)
torch.npu.synchronize(); rows.append(snap('after_atb'))
print(json.dumps(rows,indent=2))
