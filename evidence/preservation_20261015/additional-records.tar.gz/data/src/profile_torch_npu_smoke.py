import os
import torch
import torch_npu
from torch_npu.profiler import ProfilerActivity, profile, schedule, tensorboard_trace_handler

out = os.environ.get('PROFILE_OUT', '/data/vllm_project/profiles/torch_npu_smoke')
os.makedirs(out, exist_ok=True)
with profile(
    activities=[ProfilerActivity.CPU, ProfilerActivity.NPU],
    schedule=schedule(wait=0, warmup=1, active=2, repeat=1),
    on_trace_ready=tensorboard_trace_handler(out),
    record_shapes=True,
    profile_memory=True,
) as prof:
    for _ in range(3):
        x = torch.randn((1024, 1024), device='npu')
        y = torch.mm(x, x)
        torch.npu.synchronize()
        del x, y
        prof.step()
print('torch_npu_profile_done', out)
