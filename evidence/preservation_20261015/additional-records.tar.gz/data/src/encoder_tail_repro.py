import json, torch

def run(device):
    buf=torch.zeros((8,2),dtype=torch.float32,device=device)
    first=torch.full((8,2),7.0,device=device)
    second=torch.full((3,2),2.0,device=device)
    buf[:8].copy_(first); torch.npu.synchronize()
    buf[:3].copy_(second); torch.npu.synchronize()
    return {'device':str(device),'buffer_after_short_copy':buf.cpu().tolist(),'tail_rows':buf[3:].cpu().tolist()}
print(json.dumps(run('npu'),indent=2))
