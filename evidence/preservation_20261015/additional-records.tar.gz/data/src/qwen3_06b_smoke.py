import json, time, os
from vllm import LLM, SamplingParams
model='/data/vllm_project/models/Qwen3-0.6B'
t0=time.perf_counter()
llm=LLM(model=model, dtype='bfloat16', max_model_len=512, max_num_seqs=1, max_num_batched_tokens=512, gpu_memory_utilization=0.35, enforce_eager=True, trust_remote_code=True)
t1=time.perf_counter()
out=llm.generate(['Explain why graph padding can hurt latency in one sentence.'], SamplingParams(max_tokens=16, temperature=0.0))
t2=time.perf_counter()
print(json.dumps({'load_s':t1-t0,'generate_s':t2-t1,'text':out[0].outputs[0].text},ensure_ascii=False))
